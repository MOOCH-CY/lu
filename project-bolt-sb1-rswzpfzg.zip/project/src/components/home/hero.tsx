import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative h-[90vh] overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1584735175315-9d5df23860e6?auto=format&fit=crop&q=80"
          alt="Balenciaga Triple S Sneaker"
          className="h-full w-full object-cover object-center"
        />
      </div>

      {/* Animated gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/30 via-black/50 to-black/80 animate-gradient" />
      
      {/* Content */}
      <div className="relative h-full flex items-center">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl animate-slide-up">
            <h1 className="text-6xl font-bold text-white mb-6 leading-tight">
              Elevate Your
              <span className="bg-gradient-to-r from-purple-400 to-purple-200 bg-clip-text text-transparent"> Style</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Discover our exclusive collection of luxury sneakers.
              Where bold design meets unparalleled comfort.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="group">
                Shop Collection
                <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button size="lg" variant="outline">
                Watch Showcase
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Animated scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="h-14 w-8 rounded-full border-2 border-white/30 p-2">
          <div className="h-3 w-full rounded-full bg-white/50" />
        </div>
      </div>
    </section>
  );
}