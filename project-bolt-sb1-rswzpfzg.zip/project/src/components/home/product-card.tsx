import { type Product } from '@/types/product';
import { stagger } from '@/lib/animations';

interface ProductCardProps {
  product: Product;
  index: number;
}

export function ProductCard({ product, index }: ProductCardProps) {
  return (
    <div 
      className="group animate-fade-in"
      {...stagger(index)}
    >
      <div className="aspect-square overflow-hidden rounded-lg bg-gray-900">
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover object-center transition-all duration-300 group-hover:scale-105"
        />
      </div>
      <div className="mt-4 transform transition-all duration-300 group-hover:translate-y-[-4px]">
        <h3 className="text-lg font-medium text-white">{product.name}</h3>
        <p className="text-gray-400">${product.price}</p>
      </div>
    </div>
  );
}