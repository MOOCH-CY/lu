import { Link } from 'react-router-dom';
import { Footprints } from 'lucide-react';

export function Logo() {
  return (
    <Link 
      to="/" 
      className="flex items-center gap-2 group"
    >
      <Footprints 
        size={28} 
        className="text-purple-400 transition-transform group-hover:scale-110" 
      />
      <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-purple-200 bg-clip-text text-transparent">
        LUXKICK
      </span>
    </Link>
  );
}