import { Link } from 'react-router-dom';
import { Heart, Search, ShoppingBag, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Logo } from './logo';

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-black/95 backdrop-blur supports-[backdrop-filter]:bg-black/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Logo />

          <nav className="hidden md:flex space-x-8">
            <Link to="/new" className="text-sm font-medium text-gray-300 hover:text-white">New Arrivals</Link>
            <Link to="/men" className="text-sm font-medium text-gray-300 hover:text-white">Men</Link>
            <Link to="/women" className="text-sm font-medium text-gray-300 hover:text-white">Women</Link>
            <Link to="/collections" className="text-sm font-medium text-gray-300 hover:text-white">Collections</Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="hidden md:flex">
              <Search className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Heart className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <ShoppingBag className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <User className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}