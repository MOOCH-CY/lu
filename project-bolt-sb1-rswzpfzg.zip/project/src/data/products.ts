export const products = [
  {
    id: 1,
    name: 'Classic Runner Elite',
    price: 299,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80',
  },
  {
    id: 2,
    name: 'Urban Sport Pro',
    price: 249,
    image: 'https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?auto=format&fit=crop&q=80',
  },
  {
    id: 3,
    name: 'Velocity Boost X',
    price: 279,
    image: 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&q=80',
  },
  {
    id: 4,
    name: 'Air Comfort Plus',
    price: 329,
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80',
  },
] as const;