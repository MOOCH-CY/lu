export const fadeIn = 'animate-in fade-in duration-500';
export const slideUp = 'animate-in slide-in-from-bottom duration-500';
export const slideDown = 'animate-in slide-in-from-top duration-500';
export const scaleUp = 'animate-in zoom-in duration-500';

export const stagger = (index: number) => ({
  style: {
    animationDelay: `${index * 150}ms`,
  },
});