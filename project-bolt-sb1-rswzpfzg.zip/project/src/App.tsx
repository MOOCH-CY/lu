import { BrowserRouter } from 'react-router-dom';
import { Header } from '@/components/layout/header';
import { Hero } from '@/components/home/hero';
import { NewArrivals } from '@/components/home/new-arrivals';
import { Newsletter } from '@/components/home/newsletter';

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-black">
        <Header />
        <main>
          <Hero />
          <NewArrivals />
          <Newsletter />
        </main>
      </div>
    </BrowserRouter>
  );
}